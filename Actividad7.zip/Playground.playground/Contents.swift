import Foundation

//Colección de datos
var reference_cost:[Float] = [8.3,10.5,9.9]
//Recorre el ciclo for
var index:Int = 0

for i in reference_cost{
    //Por cada elemento lo multiplico por el iva
    //y lo agrego al valor original
    reference_cost[index] += i * 0.16
    //Aumento el índice para recorrer los
    //demás elementos en la colección
    index += 1
}
//Imrpimo el resultado final
print(reference_cost)

//-------------------------------------------------------

func tax(array:[Float])-> [Float]{
    var index:Int = 0
    for i in array{
        //Por cada elemento lo multiplico por el iva
        //y lo agrego al valor original
        reference_cost[index] += i * 0.16
        //Aumento el índice para recorrer los
        //demás elementos en la colección
        index += 1
    }
    return reference_cost
} 

var reference_cost:[Float] = [8.3,10.5,9.9]
print(tax(array:reference_cost))

//-------------------------------------------------------

func addTwoNumbers(a:Int, b:Int)->Int{
    return a+b
}

func addThree(first: Int, second: Int)-> Int{
    return first + second
}

print(addThree(first: addTwoNumbers(a:5, b:5), second: 5))

//-------------------------------------------------------

func changeValues(a:Int,b:Int)->(Int,Int){
    var first = a
    var second = b
    var temp = a
    first = second
    second = temp
    return (first,second)
}
print(changeValues(a:10, b:13))

//-------------------------------------------------------

let  prices = [4.2, 5.3, 8.2, 4.5]

var tax = prices.map{
    a in return a * 0.16 + a
}

print(tax)

//-------------------------------------------------------

let  prices = [4.2, 5.3, 8.2, 4.5]
//Aplico el impuesto a cada valor
var tax = prices.map{
    a in return a * 0.16 + a
}

//Filtro los impuestos mayores a 6.0
var filter = tax.filter{a in a > 6.0}
print(filter)